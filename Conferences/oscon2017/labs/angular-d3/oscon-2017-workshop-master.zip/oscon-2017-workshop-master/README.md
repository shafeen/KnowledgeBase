# OSCON 2017 Realtime Workshop

This is the repo for the Visualizing real-time data with Angular and D3 workshop.

Session: https://conferences.oreilly.com/oscon/oscon-tx/public/schedule/detail/57787

## Contents

The `app` directory contains the final build of the workshop frontend application.

The `server` directory contains the final build of the workshop server.